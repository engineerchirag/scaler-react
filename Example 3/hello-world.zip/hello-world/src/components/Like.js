import { useState } from "react";

const Like = () => {

    console.log('Rerendered');

    const [count, setCount] = useState(101);
    // let count1 = 100;

    const handleLike = () => {
        // count1++;
        // console.log(count1);
        const newValue = count + 1;
        setCount(newValue);
    }

    return (
        <div className="like-wrapper">
            {/* <div><button onclick="handleLike()">Like</button> - {count}</div>  // This is how we can in JS */}
            <div><button onClick={handleLike}>Like</button> - State Variable: {count}, </div> 
            {/* Normal Variable: {count1} */}
        </div>
    )
}

export default Like;
