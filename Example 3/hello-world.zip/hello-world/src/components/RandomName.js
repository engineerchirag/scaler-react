import { useState } from "react"

const RandomName = () => {

    const [randomId, setRandomId] = useState('123123');
    const [randomName, setRandomName] = useState('768');

    const changeIdentity = () => {
        const newRandomId  = Math.random();
        setRandomId(newRandomId);


        const newRandomName = Math.random();
        setRandomName(newRandomName);

    }

    return (
        <div onClick={changeIdentity}>
            <span>Id: {randomId}</span>
            <span>Name: Xyz{randomName}</span>
        </div>
    )
}

export default RandomName;