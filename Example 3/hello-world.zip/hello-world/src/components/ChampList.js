export const ChampList = () => {
    const heading = 'ChampList';
  return (
    <div>
      <h2>{heading}</h2>
      <ul>
        <li>Prabir</li>
        <li>Souvik</li>
        <li>Abhishek</li>
        <li>Krishna</li>
      </ul>
    </div>
  );
};

export const JakaasStudents = () => {
  return (
    <div>
      <h2>JakaasStudents</h2>
      <ul>
        <li>Revathi</li>
        <li>Venketash</li>
        <li>Sachin</li>
      </ul>
    </div>
  );
};
