const Favourites = () => {
    return (
        <h1>Favourites</h1>
    )
}

export default Favourites;