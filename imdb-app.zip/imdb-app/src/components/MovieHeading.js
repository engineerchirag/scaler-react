const MovieHeading = () => {
    return (
        <div className="movie-heading">
            Trending
        </div>
    )
}

export default MovieHeading;