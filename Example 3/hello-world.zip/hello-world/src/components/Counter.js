import { useState } from "react";

const Counter = (props) => {
    console.log(props);
    const [count, setCount] = useState(props.initialValue);

    const decreaseCount = () => {
        if (count <= 0) {
            return;
        }
        setCount(count - 1);
    }

    const increaseCount = () => {
        if (count >= 10) {
            return;
        }
        setCount(count + 1);
    }

    return (
        <div>
            <h1>{props.counterName} Counter </h1>
            <div>
                <button onClick={decreaseCount}>-</button>
                {count}
                <button onClick={increaseCount}>+</button>
            </div>
        </div>
    )
}

export default Counter;