

const Banner = () => {
    return (
        <div className="banner">
            <div className="detail">
                <h1>Don't Breathe 2</h1>
                <p>The Blind Man has been hiding out for several years in an isolated cabin and has taken in and raised a young girl orphaned from a devastating house fire. Their quiet life together is shattered when a group of criminals kidnap the girl, forcing the Blind Man to leave his safe haven to save her.</p>
            </div>
        </div>
    )
}

export default Banner;