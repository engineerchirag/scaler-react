import logo from './logo.svg';
import './App.css'
import LifeCycleExample from './components/LifeCycleExample';
import { useState } from 'react';
import Header from './components/Header';
import Banner from './components/Banner';
import MovieListWrapper from './components/MovieListWrapper';

function App() {
  return (
   <div className='container'>
      <Header/>
      <Banner />
      <MovieListWrapper />
   </div>
  );
}

export default App;
