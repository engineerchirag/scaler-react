const MovieCard = ({ movie }) => {
    return (
        <div className="movie-card" style={ {backgroundImage: `url("https://image.tmdb.org/t/p/original/${movie.backdrop_path}")`} }>
            <h3>{movie.title}</h3>
            <button>Add To Favourites</button>
        </div>
    )
}

export default MovieCard;