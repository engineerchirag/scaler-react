const PocketMoney = ({ money, changePocketMoney }) => {
    const handleCry = () => {
        // console.log('Chup ho ja mere baap!');
        changePocketMoney();
    }
    return (
        <div>
            <div>Money: Rs.{money}</div>
            <div><button onClick={handleCry}>Cry</button></div>
        </div>
    )
}

export default PocketMoney;