const Header = () => {
    return (
        <div className="header">
            Header
        </div>
    )
}

export default Header;